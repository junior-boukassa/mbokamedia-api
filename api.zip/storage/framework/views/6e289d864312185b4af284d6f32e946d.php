<?php echo e($slot); ?>

<?php /**PATH /Users/pro/mboka-media/apps/api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>