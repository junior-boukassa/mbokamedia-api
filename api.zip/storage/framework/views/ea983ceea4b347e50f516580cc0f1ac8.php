<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/pro/mboka-media/apps/api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>